import numpy as np 

class KeywordTagger: 
  def __init__(self): 
    self.W1 = np.load('W1.npy')
    self.V = np.load('V.npy')
    self.topic_names_dict = {1: "community events and workshops", 
                             2: "social good and fundraising", 
                             3: "cultural and artistic events", 
                             4: "career development", 
                             5: "volunteering", 
                             6: "theater and performing arts", 
                             7: "recreation and nightlife", 
                             8: "pre-professional events", 
                             9: "social justice and advocacy", 
                             10: "food and snacks",
                             11: "other"}
  
  def clean_doc(self, doc): 
    cleaned_doc = doc.replace('\n', '')
    cleaned_doc = cleaned_doc.replace('\Terminate\\', '\n')
    cleaned_doc = cleaned_doc.replace('Subject: ', '')
    return cleaned_doc 
  
  def vectorize_doc(self, cleaned_doc):
    word_to_index = {word: index for index, word in enumerate(self.V)}
    word_counts = {}
    words = cleaned_doc.split()
    for word in words:
      if word in word_to_index:
        word_index = word_to_index[word]
        word_counts[word_index] = word_counts.get(word_index, 0) + 1
    
    document_vector = [word_counts.get(index, 0) for index in range(len(self.V))]
    return document_vector

  def list_topics_above_proportion(self, topic_distribution, threshold):
    topics_above_threshold = []
    
    for topic_index, proportion in enumerate(topic_distribution):
        if proportion > threshold:
            topics_above_threshold.append(topic_index + 1)  
    return topics_above_threshold

  def get_topic_numbers(self, cleaned_doc, threshold=0.3):
      document_vector = self.vectorize_doc(cleaned_doc)  
      document_topic_distribution = np.dot(document_vector, self.W1)  
      topics_above_threshold = self.list_topics_above_proportion(document_topic_distribution, threshold)
      topics_sorted_by_proportion = sorted(topics_above_threshold, key=lambda topic_index: document_topic_distribution[topic_index - 1], reverse=True)
      return topics_sorted_by_proportion
    
  def tag(self, doc): 
      cleaned_doc = self.clean_doc(doc)
      topic_numbers = self.get_topic_numbers(cleaned_doc)
      tags = [self.topic_names_dict.get(topic) for topic in topic_numbers]
      if tags == []: 
        return ["other"]
      else: 
        return tags 




doc = "Calling All Actors, Dancers and Singers for Head Over Heels Auditions!When a soothsayer foretells the downfall of Arcadia, the King goes on a quest to avoid his fate. A 16th century love story to the tune of the Go-Go's. \"Head Over Heels\" is a hilarious modern-day fairytale told through pop-punk music and posh prose. Centering queer love, mistaken identities, changing social norms, and iconic songs, \"Head Over Heels\" is a feel-good romp that celebrates the joy of acceptance and community."
tagger = KeywordTagger() 
tagger.tag(doc)